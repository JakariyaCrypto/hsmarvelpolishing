
<?php $__env->startSection('title','HS Polishing'); ?>

<?php $__env->startSection('content'); ?>
  <!-- services -->
  <div class="service-section">
    <div class="container mt text-center">
      <div class="row">
          <div class="col-sm-12">
            <div class="section-title pb">
              <h4>Our Services</h4>
            </div>
          </div>
        </div>
    </div>
    <div class="gallery-service">
      <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(asset($service->image)); ?>">
        <img src="<?php echo e(asset($service->image)); ?>">
        <div class="service-content-overlap">
          <span><?php echo e($service->title); ?></span>
        </div>
      </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('fontend/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel\htdocs\HSPolishing\resources\views/fontend/service.blade.php ENDPATH**/ ?>
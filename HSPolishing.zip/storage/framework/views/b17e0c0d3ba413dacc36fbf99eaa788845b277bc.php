
<?php $__env->startSection('title','HS Polishing'); ?>

<?php $__env->startSection('content'); ?>
  <!-- services -->
  <div class="service-section">
    <div class="container mt text-center">
      <div class="row">
          <div class="col-sm-12">
            <div class="section-title pb">
              <h4>Our Works</h4>
            </div>
          </div>
        </div>
    </div>
    <div class="gallery-work">
      <?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $work): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(asset($work->image)); ?>">
        <img src="<?php echo e(asset($work->image)); ?>">
      </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('fontend/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel\htdocs\HSPolishing\resources\views/fontend/work.blade.php ENDPATH**/ ?>
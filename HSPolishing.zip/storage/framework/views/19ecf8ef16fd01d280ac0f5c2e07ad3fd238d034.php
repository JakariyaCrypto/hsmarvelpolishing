
<?php $__env->startSection('title','Dashboard/Service'); ?>
<?php $__env->startSection('content'); ?>

<div class="main-content">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 mt-4">
                    <?php if(session()->has('success')): ?>
                    <div class="alert alert-success">
                        <span><?php echo e(session()->get('success')); ?></span>
                    </div>
                    <?php endif; ?>

                    <?php if(session()->has('danger')): ?>
                    <div class="alert alert-danger">
                        <span><?php echo e(session()->get('danger')); ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="card">
                        <div class="card-header bg-primary text-white"><i class="fas fa-plus"></i> Add Service</div>
                        <div class="card-body">
                            <form action="<?php echo e(route('add.service')); ?>" method="post" novalidate="novalidate" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                            	<div class="row">
                            		<div class="col-md-5">
                            			<div class="form-group">
		                                    <label for="name" class="control-label mb-1">Service Title <span class="text text-danger">*</span></label>
		                                    <input id="title" name="title" type="text" class="form-control" value="<?php echo e($title); ?>">
                                            <input type="hidden" name="id" value="<?php echo e($id); ?>">
		                                </div>
                                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger">
                                                <span><?php echo e($message); ?></span>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            		</div>
                            		<div class="col-md-5">
                            			<div class="form-group">
		                                    <label for="name" class="control-label mb-1">Service Image <span class="text text-danger">*</span></label>
		                                    <input id="image" name="image" type="file" class="form-control" >
		                                </div>
                                        <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger">
                                                <span><?php echo e($message); ?></span>
                                            </div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        <?php if($id): ?>
                                            <img src="<?php echo e(asset($image)); ?>" style="width:120px;height: auto;">
                                        <?php endif; ?>
                            		</div>
                                    <div class="col-md-2 mt-4 p pt-1">
                                    <?php if($id): ?>
                                    <button type="submit" class="btn btn-primary btn-sm">
                                     <i class="fa fa-check-circle"></i> Update
                                    </button>   
                                    <?php else: ?>
                                    <button type="submit" class="btn btn-primary btn-sm">
                                     <i class="fa fa-check-circle"></i> Submit
                                    </button>  
                                    <?php endif; ?>
                                    </div>
                            	</div>
                                
                                

                            </form>
                        	</div>
                    	</div>
                	</div>
            	</div>
            	<div class="row m-t-30">
                    <div class="col-md-12">
                        <!-- DATA TABLE-->
                        <div class="table-responsive m-b-40">
                            <table class="table table-borderless table-data3">
                                <thead>
                                    <tr>
                                        <th>SL</th>
                                        <th>Title</th>
                                        <th>Image</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                        $i =1;
                                    ?>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($i++); ?></td>
                                        <td><?php echo e($service->title); ?></td>
                                        <td><img style="width: 100px;height: 70px" src="<?php echo e(asset($service->image)); ?>"></td>
                                        <td>
                                            <a href="<?php echo e(url('/dashboard/destroy-service')); ?>/<?php echo e($service->id); ?>" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></a>
                                            <a href="<?php echo e(url('/dashboard/add-service')); ?>/<?php echo e($service->id); ?>" class="btn btn-sm btn-outline-warning"><i class="fas fa-edit"></i></a>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- END DATA TABLE-->
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('backend/layout/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\Laravel\htdocs\HSPolishing\resources\views/backend/service/add-service.blade.php ENDPATH**/ ?>


  var swiper = new Swiper(".sliderHome", {
         centeredSlides: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      grapbCursor: true,
      effect: 'fade',
    
        pagination: {
          el: ".swiper-pagination",
          clickable: true,
        },
        loop:true,
      });



